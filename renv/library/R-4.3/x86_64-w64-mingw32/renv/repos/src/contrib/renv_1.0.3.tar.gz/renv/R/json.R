
renv_json_quote <- function(text) {
  encodeString(text, quote = "\"", justify = "none")
}
